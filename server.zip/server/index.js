const WebSocket = require('ws');
let premessage = '';

// WebSocketサーバーのURLを設定
const url = 'wss://metaearthwave-backend-stsiczr2ha-dt.a.run.app';
const connection = new WebSocket(url);
connection.onopen = () => {
  console.log('WebSocketに接続しました');
};

const {TwitterApi} = require('twitter-api-v2');
const Server = require('ws').Server;

if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}
const s = new Server({port: process.env.PORT || 5001});


const language = require('@google-cloud/language');
const MongoClient = require('mongodb').MongoClient;
const mongoDB =
    new MongoClient('mongodb+srv://purankuton:1192tukurou@cluster0.ygb6h99.mongodb.net/?retryWrites=true&w=majority');
const languageClient =
    new language.LanguageServiceClient();


s.on('connection', function(ws) {
  mongoDB.connect(async (err) => {
    if (err) {
      console.error(err);
    }
    connection.onmessage = async (e) => {
      console.log(`サーバーからのメッセージ: ${typeof e.data}`);
      if (premessage !== e.data) {
        await s.clients.forEach(function(client) {
          client.send(e.data);
          premessage = e.data;
        });
      }
    };
    const collection =
          mongoDB.db('metaearthwave').collection('Tweet');
    const tweets = [];
    const Docs = await collection.find({});
    await Docs.forEach((doc) => {
      tweets.push(doc);
    });
    const score = await mongoDB
        .db('metaearthwave')
        .collection('Score')
        .findOne({});
    await s.clients.forEach(function(client) {
      client.send(JSON.stringify({
        tweets,
        score: {
          positiveScore: score.positiveScore,
          negativeScore: score.negativeScore,
        },
      }));
    });
    setTimeout(() => {
      mongoDB.close();
    }, 10000);
  });
  ws.on('message', async function(data) {
    try {
      const mes = JSON.parse(data);
      const tweetText = mes.tweetText
          .replace(/((h?)(ttps?:\/\/[a-zA-Z0-9.\-_@:/~?%&;=+#',()*!]+))/g,
              '')
          .replace(/#+([a-zA-Z0-9亜-熙ぁ-んァ-ヶー-龥朗-鶴.\-_]+)/g, '');
      const twitterKey = {
        appKey: process.env.TWITTER_ID,
        appSecret: process.env.TWITTER_SECRET,
        accessToken: mes.accessToken,
        accessSecret: mes.accessTokenSecret,
      };
      const twitterClient = await new TwitterApi(twitterKey);
      await twitterClient.v2
          .tweet(tweetText +
              ' #MetaEarthWave ' + process.env.WEBSITEURL);
      const d = {
        content: tweetText,
        type: 'PLAIN_TEXT',
      };
      const r = await languageClient
          .analyzeSentiment({document: d});

      const sentiment = r[0].documentSentiment;
      const waveDoc =
          {score: sentiment.score,
            loc: mes.loc,
            account: {
              id: mes.id,
              name: mes.name,
              screenName: mes.name,
              profileImage: mes.image,
            },
            text: tweetText,
            time: new Date(Date()),
          };
      mongoDB.connect((err) => {
        const collection =
            mongoDB.db('metaearthwave').collection('Tweet');
        collection.insertOne(waveDoc, async () => {
          const tweets2 = [];
          const Docs = await collection.find({});
          await Docs.forEach((doc) => {
            tweets2.push(doc);
          });
          const score = await mongoDB
              .db('metaearthwave')
              .collection('Score')
              .findOne({});
          if (sentiment.score > 0) {
            score.positiveScore =
                Number(score.positiveScore) + sentiment.score;
          } else {
            score.negativeScore =
                Number(score.negativeScore) + sentiment.score;
          }
          await mongoDB
              .db('metaearthwave')
              .collection('Score')
              .updateOne({}, {$set: score});
          await s.clients.forEach(function(client) {
            client.send(JSON.stringify({
              tweets: tweets2,
              score: {
                positiveScore: score.positiveScore,
                negativeScore: score.negativeScore,
              }}));
          });
          setTimeout(() => {
            mongoDB.close();
          }, 10000);
        });
      });
    } catch (err) {
      console.error(err);
    }
  });
});


